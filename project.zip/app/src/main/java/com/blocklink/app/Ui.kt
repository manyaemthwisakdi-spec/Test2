package com.blocklink.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

object C {
    val BG = 0xFF0A0A12.toInt()
    val CARD = 0xFF161625.toInt()
    val CARD2 = 0xFF22223A.toInt()
    val BLUE = 0xFF38BDF8.toInt()
    val PINK = 0xFFFF5FA2.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val BLACK = 0xFF000000.toInt()
    val MUTED = 0xFF9CA3AF.toInt()
    val RED = 0xFFFF5252.toInt()
    val GREEN = 0xFF4ADE80.toInt()
}

const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

fun errJson(msg: String): JSONObject = JSONObject().put("ok", false).put("err", msg)

fun JSONArray?.objs(): List<JSONObject> {
    val out = ArrayList<JSONObject>()
    if (this == null) return out
    for (i in 0 until length()) out.add(getJSONObject(i))
    return out
}

fun hexToBytes(h: String): ByteArray {
    val n = h.length / 2
    val b = ByteArray(n)
    for (i in 0 until n) {
        b[i] = ((Character.digit(h[2 * i], 16) shl 4) or Character.digit(h[2 * i + 1], 16)).toByte()
    }
    return b
}

fun bytesToHex(b: ByteArray, off: Int, len: Int): String {
    val sb = StringBuilder()
    for (i in off until off + len) {
        sb.append(String.format("%02x", b[i].toInt() and 0xff))
    }
    return sb.toString()
}

fun b64Bitmap(s: String?): Bitmap? {
    if (s == null || s.isEmpty()) return null
    return try {
        val b = Base64.decode(s, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(b, 0, b.size)
    } catch (e: Exception) {
        null
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.roundBg(color: Int, r: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    return g
}

fun Context.gradBg(r: Int): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.BLUE, C.PINK))
    g.cornerRadius = dp(r).toFloat()
    return g
}

fun Context.tv(text: String, size: Float = 15f, color: Int = C.WHITE, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.vbox(pad: Int = 0): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.gap(h: Int): View {
    val v = View(this)
    v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
    return v
}

// kind: 0 = gradient blue->pink, 1 = dark, 2 = white
fun Context.btn(text: String, kind: Int = 0, onClick: () -> Unit): TextView {
    val textColor = if (kind == 2) C.BLACK else C.WHITE
    val t = tv(text, 16f, textColor, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(16), dp(13), dp(16), dp(13))
    t.background = when (kind) {
        0 -> gradBg(26)
        2 -> roundBg(C.WHITE, 26)
        else -> roundBg(C.CARD2, 26)
    }
    t.isClickable = true
    t.setOnClickListener { onClick() }
    val p = LinearLayout.LayoutParams(MATCH, WRAP)
    p.topMargin = dp(10)
    t.layoutParams = p
    return t
}

fun Context.smallBtn(text: String, kind: Int = 0, onClick: () -> Unit): TextView {
    val t = tv(text, 13f, C.WHITE, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.background = if (kind == 0) gradBg(18) else roundBg(C.CARD2, 18)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

fun Context.link(text: String, onClick: () -> Unit): TextView {
    val t = tv(text, 15f, C.BLUE, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(8), dp(12), dp(8), dp(12))
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

fun Context.input(hint: String, pw: Boolean = false, maxLen: Int = 0, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setHintTextColor(C.MUTED)
    e.setTextColor(C.WHITE)
    e.background = roundBg(C.CARD2, 14)
    e.setPadding(dp(14), dp(12), dp(14), dp(12))
    e.inputType = if (pw) (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD) else type
    if (maxLen > 0) e.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(maxLen))
    val p = LinearLayout.LayoutParams(MATCH, WRAP)
    p.topMargin = dp(10)
    e.layoutParams = p
    return e
}

// Only allow certain characters (and optionally force lowercase)
fun charFilter(thai: Boolean, lower: Boolean): InputFilter {
    return InputFilter { src, start, end, _, _, _ ->
        val sb = StringBuilder()
        for (i in start until end) {
            var ch = src[i]
            if (lower && ch in 'A'..'Z') ch = ch + 32
            val okc = (ch in 'a'..'z') || (!lower && ch in 'A'..'Z') || (ch in '0'..'9') || ch == '_' ||
                (thai && ch in '\u0E00'..'\u0E7F')
            if (okc) sb.append(ch)
        }
        val res = sb.toString()
        if (res == src.subSequence(start, end).toString()) null else res
    }
}

fun Context.avatarView(b64: String?, sizeDp: Int): ImageView {
    val iv = ImageView(this)
    iv.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    iv.scaleType = ImageView.ScaleType.CENTER_CROP
    iv.background = roundBg(C.CARD2, sizeDp)
    iv.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }
    iv.clipToOutline = true
    val bm = b64Bitmap(b64)
    if (bm != null) iv.setImageBitmap(bm) else iv.setImageResource(R.drawable.logo)
    return iv
}

fun pwError(p: String, handle: String): String? {
    if (p.length < 8) return "รหัสผ่านต้องยาวอย่างน้อย 8 ตัว"
    if (p.length > 64) return "รหัสผ่านยาวเกินไป (สูงสุด 64 ตัว)"
    if (!p.any { it in '0'..'9' }) return "รหัสผ่านต้องมีตัวเลขอย่างน้อย 1 ตัว"
    if (!p.any { it in 'a'..'z' || it in 'A'..'Z' }) return "รหัสผ่านต้องมีภาษาอังกฤษอย่างน้อย 1 ตัว"
    if (p.any { it.isWhitespace() }) return "รหัสผ่านห้ามมีเว้นวรรค"
    if (handle.isNotEmpty() && p.equals(handle, ignoreCase = true)) return "รหัสผ่านต้องไม่เหมือน @ ของคุณ"
    return null
}

private fun Context.switchRow(title: String, sub: String): Pair<LinearLayout, Switch> {
    val row = hbox()
    row.setPadding(0, dp(8), 0, dp(8))
    val texts = vbox()
    texts.addView(tv(title, 15f, C.WHITE, true))
    texts.addView(tv(sub, 12f, C.MUTED))
    row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
    val sw = Switch(this)
    sw.thumbTintList = ColorStateList.valueOf(C.WHITE)
    sw.trackTintList = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(C.PINK, C.MUTED)
    )
    row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
    return Pair(row, sw)
}

// Host settings window: exactly one of the two switches is always on.
fun hostSetupView(ctx: Context, world: String, version: String, initMode: String,
                  okText: String, onOk: (String) -> Unit, onSkip: (() -> Unit)?): View {
    val box = ctx.vbox(20)
    box.background = ctx.roundBg(C.CARD, 22)
    box.addView(ctx.tv("ตั้งค่าโลกของคุณ", 20f, C.WHITE, true))
    box.addView(ctx.tv("$world  •  $version", 14f, C.BLUE))
    box.addView(ctx.gap(8))
    val rowAll = ctx.switchRow("อนุญาตให้คนอื่นจอย (รวมเพื่อน)", "ปิด = โลกจะไม่โผล่ให้คนที่ไม่ใช่เพื่อน")
    val rowFr = ctx.switchRow("อนุญาตเพื่อนจอย", "เปิด = เฉพาะเพื่อนเท่านั้นที่เห็นโลกนี้")
    val swAll = rowAll.second
    val swFr = rowFr.second
    swAll.isChecked = initMode == "all"
    swFr.isChecked = initMode != "all"
    val guard = BooleanArray(1)
    swAll.setOnCheckedChangeListener { _, on ->
        if (!guard[0]) {
            guard[0] = true
            swFr.isChecked = !on
            guard[0] = false
        }
    }
    swFr.setOnCheckedChangeListener { _, on ->
        if (!guard[0]) {
            guard[0] = true
            swAll.isChecked = !on
            guard[0] = false
        }
    }
    box.addView(rowAll.first)
    box.addView(rowFr.first)
    box.addView(ctx.tv("ต้องเปิดอย่างใดอย่างหนึ่งเสมอ", 12f, C.MUTED))
    box.addView(ctx.btn(okText) { onOk(if (swAll.isChecked) "all" else "friends") })
    if (onSkip != null) box.addView(ctx.btn("ไม่แชร์ตอนนี้", 1) { onSkip() })
    return box
}
