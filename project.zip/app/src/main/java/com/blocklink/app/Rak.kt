package com.blocklink.app

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.Random

/** Minimal RakNet "unconnected ping / pong" used by Minecraft Bedrock LAN discovery. */
object Rak {
    private val MAGIC = byteArrayOf(
        0x00, 0xff.toByte(), 0xff.toByte(), 0x00, 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(),
        0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0x12, 0x34, 0x56, 0x78
    )
    private val rnd = Random()

    fun ping(): ByteArray {
        val b = ByteBuffer.allocate(33)
        b.put(0x01.toByte())
        b.putLong(System.currentTimeMillis())
        b.put(MAGIC)
        b.putLong(rnd.nextLong())
        return b.array()
    }

    fun isPing(d: ByteArray, n: Int): Boolean {
        if (n < 25) return false
        if (d[0] != 0x01.toByte() && d[0] != 0x02.toByte()) return false
        for (i in 0 until 16) {
            if (d[9 + i] != MAGIC[i]) return false
        }
        return true
    }

    /** Build a pong that echoes the time of [ping] (bytes 1..8). */
    fun pong(ping: ByteArray, guid: Long, motd: String): ByteArray {
        val s = motd.toByteArray(Charsets.UTF_8)
        val b = ByteBuffer.allocate(1 + 8 + 8 + 16 + 2 + s.size)
        b.put(0x1c.toByte())
        b.put(ping, 1, 8)
        b.putLong(guid)
        b.put(MAGIC)
        b.putShort(s.size.toShort())
        b.put(s)
        return b.array()
    }

    fun parsePong(d: ByteArray, n: Int): String? {
        if (n < 35 || d[0] != 0x1c.toByte()) return null
        val len = ((d[33].toInt() and 0xff) shl 8) or (d[34].toInt() and 0xff)
        if (35 + len > n) return null
        return String(d, 35, len, Charsets.UTF_8)
    }

    /** Ask the local game (127.0.0.1:port) for its LAN info. Returns the raw MOTD string or null. */
    fun probe(port: Int): String? {
        var s: DatagramSocket? = null
        try {
            s = DatagramSocket()
            s.soTimeout = 1200
            val p = ping()
            s.send(DatagramPacket(p, p.size, InetAddress.getByName("127.0.0.1"), port))
            val buf = ByteArray(2048)
            val r = DatagramPacket(buf, buf.size)
            s.receive(r)
            return parsePong(buf, r.length)
        } catch (e: Exception) {
            return null
        } finally {
            s?.close()
        }
    }

    /** Take the host's real MOTD and rewrite: owner name, unique guid and our local proxy port. */
    fun rewriteMotd(raw: String, name: String, guid: Long, port: Int): String {
        val f = raw.split(";").toMutableList()
        while (f.size < 12) f.add("")
        f[1] = name
        f[6] = guid.toString()
        f[10] = port.toString()
        f[11] = port.toString()
        return f.joinToString(";")
    }
}
