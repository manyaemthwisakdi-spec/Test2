package com.blocklink.app

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

private fun hdr(role: Char, sid: Int): ByteArray =
    byteArrayOf(role.code.toByte()) + ByteBuffer.allocate(4).putInt(sid).array()

/** Joiner side: listens on a local UDP port; the game connects to 127.0.0.1:localPort. */
class JoinerProxy(relayHost: String, private val sid: Int, private val localPort: Int) {
    @Volatile private var running = true
    private val relay = InetSocketAddress(relayHost, 9001)
    private var local: DatagramSocket? = null
    private var up: DatagramSocket? = null
    @Volatile private var gameAddr: SocketAddress? = null

    fun start() {
        val l = DatagramSocket(localPort)
        val u = DatagramSocket()
        local = l
        up = u
        val h = hdr('J', sid)
        Thread { // game -> relay
            try {
                val buf = ByteArray(65535)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    l.receive(p)
                    gameAddr = p.socketAddress
                    val d = h + buf.copyOf(p.length)
                    u.send(DatagramPacket(d, d.size, relay))
                }
            } catch (_: Exception) {}
        }.start()
        Thread { // relay -> game
            try {
                val buf = ByteArray(65535)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    u.receive(p)
                    val a = gameAddr ?: continue
                    l.send(DatagramPacket(buf, p.length, a))
                }
            } catch (_: Exception) {}
        }.start()
        Thread { // keepalive so the relay learns our address
            try {
                while (running) {
                    u.send(DatagramPacket(h, h.size, relay))
                    Thread.sleep(5000)
                }
            } catch (_: Exception) {}
        }.start()
    }

    fun stop() {
        running = false
        try { local?.close() } catch (_: Exception) {}
        try { up?.close() } catch (_: Exception) {}
    }
}

/** Host side: one local socket per joiner session, talking to the game on 127.0.0.1:gamePort. */
class HostBridge(relayHost: String, private val gamePort: Int) {
    @Volatile private var running = true
    private val relay = InetSocketAddress(relayHost, 9001)
    private var up: DatagramSocket? = null
    private val games = ConcurrentHashMap<Int, DatagramSocket>()

    fun start() {
        val u = DatagramSocket()
        up = u
        Thread { // relay -> game
            try {
                val buf = ByteArray(65535)
                val loop = InetAddress.getByName("127.0.0.1")
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    u.receive(p)
                    if (p.length < 5) continue
                    val sid = ByteBuffer.wrap(buf, 0, 4).int
                    val g = games[sid] ?: continue
                    g.send(DatagramPacket(buf, 4, p.length - 4, loop, gamePort))
                }
            } catch (_: Exception) {}
        }.start()
        Thread { // keepalives for every session
            try {
                while (running) {
                    for (sid in games.keys) {
                        val d = hdr('H', sid)
                        u.send(DatagramPacket(d, d.size, relay))
                    }
                    Thread.sleep(5000)
                }
            } catch (_: Exception) {}
        }.start()
    }

    fun addSession(sid: Int) {
        val u = up ?: return
        val g = DatagramSocket()
        games[sid] = g
        val h = hdr('H', sid)
        try { u.send(DatagramPacket(h, h.size, relay)) } catch (_: Exception) {}
        Thread { // game -> relay
            try {
                val buf = ByteArray(65535)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    g.receive(p)
                    val d = h + buf.copyOf(p.length)
                    u.send(DatagramPacket(d, d.size, relay))
                }
            } catch (_: Exception) {}
        }.start()
    }

    fun stop() {
        running = false
        try { up?.close() } catch (_: Exception) {}
        for (g in games.values) { try { g.close() } catch (_: Exception) {} }
        games.clear()
    }
}
