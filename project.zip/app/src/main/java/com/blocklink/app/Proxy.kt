package com.blocklink.app

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

private const val ROLE_H: Byte = 0x48 // 'H'
private const val ROLE_J: Byte = 0x4A // 'J'

fun sleepMs(ms: Long) {
    try {
        Thread.sleep(ms)
    } catch (e: Exception) {
    }
}

/**
 * Joiner side. Minecraft connects to 127.0.0.1:[port]; everything is relayed (UDP) to the server
 * with this session's id, and replies are sent back to the game.
 */
class JoinerProxy(private val relayHost: String, private val relayPort: Int, sidHex: String, val port: Int) {
    private val sid = hexToBytes(sidHex)
    @Volatile private var run = false
    private var local: DatagramSocket? = null
    private var remote: DatagramSocket? = null
    @Volatile private var gameAddr: SocketAddress? = null
    @Volatile private var relay: InetSocketAddress? = null
    val up = AtomicLong()
    val down = AtomicLong()

    fun start(): Boolean {
        try {
            val l = DatagramSocket(null)
            l.reuseAddress = true
            l.bind(InetSocketAddress(port))
            l.soTimeout = 1000
            val r = DatagramSocket()
            r.soTimeout = 1000
            local = l
            remote = r
        } catch (e: Exception) {
            return false
        }
        run = true
        Thread { upLoop() }.start()
        Thread { downLoop() }.start()
        Thread { keepLoop() }.start()
        return true
    }

    private fun relayAddr(): InetSocketAddress? {
        var r = relay
        if (r == null) {
            try {
                r = InetSocketAddress(InetAddress.getByName(relayHost), relayPort)
                relay = r
            } catch (e: Exception) {
                return null
            }
        }
        return r
    }

    private fun upLoop() {
        val buf = ByteArray(4096)
        while (run) {
            try {
                val p = DatagramPacket(buf, buf.size)
                local!!.receive(p)
                gameAddr = p.socketAddress
                val ra = relayAddr() ?: continue
                val out = ByteArray(9 + p.length)
                out[0] = ROLE_J
                System.arraycopy(sid, 0, out, 1, 8)
                System.arraycopy(buf, 0, out, 9, p.length)
                remote!!.send(DatagramPacket(out, out.size, ra))
                up.incrementAndGet()
            } catch (e: SocketTimeoutException) {
            } catch (e: Exception) {
                if (run) sleepMs(200)
            }
        }
    }

    private fun downLoop() {
        val buf = ByteArray(4096)
        while (run) {
            try {
                val p = DatagramPacket(buf, buf.size)
                remote!!.receive(p)
                val ga = gameAddr
                if (p.length > 8 && ga != null) {
                    local!!.send(DatagramPacket(buf, 8, p.length - 8, ga))
                    down.incrementAndGet()
                }
            } catch (e: SocketTimeoutException) {
            } catch (e: Exception) {
                if (run) sleepMs(200)
            }
        }
    }

    private fun keepLoop() {
        val ka = ByteArray(9)
        ka[0] = ROLE_J
        System.arraycopy(sid, 0, ka, 1, 8)
        while (run) {
            try {
                val ra = relayAddr()
                if (ra != null) remote!!.send(DatagramPacket(ka, ka.size, ra))
            } catch (e: Exception) {
            }
            sleepMs(4000)
        }
    }

    fun stop() {
        run = false
        try {
            local?.close()
        } catch (e: Exception) {
        }
        try {
            remote?.close()
        } catch (e: Exception) {
        }
    }
}

/**
 * Host side. For every joined session we open a UDP socket towards the local game
 * (127.0.0.1:[gamePort]) so the game sees each remote player as a separate LAN client.
 */
class HostBridge(private val relayHost: String, private val relayPort: Int, gameHost: String, private val gamePort: Int) {
    @Volatile private var run = false
    private var remote: DatagramSocket? = null
    private val games = ConcurrentHashMap<String, DatagramSocket>()
    @Volatile private var relay: InetSocketAddress? = null
    private val loopback: InetAddress = InetAddress.getByName(gameHost)
    val up = AtomicLong()
    val down = AtomicLong()

    fun start() {
        run = true
        val r = DatagramSocket()
        r.soTimeout = 1000
        remote = r
        Thread { relayLoop() }.start()
        Thread { keepLoop() }.start()
    }

    private fun relayAddr(): InetSocketAddress? {
        var r = relay
        if (r == null) {
            try {
                r = InetSocketAddress(InetAddress.getByName(relayHost), relayPort)
                relay = r
            } catch (e: Exception) {
                return null
            }
        }
        return r
    }

    fun sync(sids: Collection<String>) {
        for (s in sids) add(s)
        for (k in games.keys.toList()) {
            if (!sids.contains(k)) remove(k)
        }
    }

    fun add(sid: String) {
        if (sid.length != 16 || games.containsKey(sid)) return
        try {
            val g = DatagramSocket()
            g.soTimeout = 1000
            games[sid] = g
            Thread { gameLoop(sid, g) }.start()
        } catch (e: Exception) {
        }
    }

    fun remove(sid: String) {
        val g = games.remove(sid)
        try {
            g?.close()
        } catch (e: Exception) {
        }
    }

    private fun gameLoop(sid: String, g: DatagramSocket) {
        val sidB = hexToBytes(sid)
        val buf = ByteArray(4096)
        while (run && games[sid] === g) {
            try {
                val p = DatagramPacket(buf, buf.size)
                g.receive(p)
                val ra = relayAddr() ?: continue
                val out = ByteArray(9 + p.length)
                out[0] = ROLE_H
                System.arraycopy(sidB, 0, out, 1, 8)
                System.arraycopy(buf, 0, out, 9, p.length)
                remote!!.send(DatagramPacket(out, out.size, ra))
                up.incrementAndGet()
            } catch (e: SocketTimeoutException) {
            } catch (e: Exception) {
                if (games[sid] === g) sleepMs(100)
            }
        }
    }

    private fun relayLoop() {
        val buf = ByteArray(4096)
        while (run) {
            try {
                val p = DatagramPacket(buf, buf.size)
                remote!!.receive(p)
                if (p.length <= 8) continue
                val key = bytesToHex(buf, 0, 8)
                val g = games[key]
                if (g != null) {
                    g.send(DatagramPacket(buf, 8, p.length - 8, loopback, gamePort))
                    down.incrementAndGet()
                }
            } catch (e: SocketTimeoutException) {
            } catch (e: Exception) {
                if (run) sleepMs(100)
            }
        }
    }

    private fun keepLoop() {
        while (run) {
            for (sid in games.keys.toList()) {
                try {
                    val ra = relayAddr()
                    if (ra != null) {
                        val ka = ByteArray(9)
                        ka[0] = ROLE_H
                        System.arraycopy(hexToBytes(sid), 0, ka, 1, 8)
                        remote!!.send(DatagramPacket(ka, ka.size, ra))
                    }
                } catch (e: Exception) {
                }
            }
            sleepMs(4000)
        }
    }

    fun stop() {
        run = false
        for (k in games.keys.toList()) remove(k)
        try {
            remote?.close()
        } catch (e: Exception) {
        }
    }
}

/**
 * Answers Minecraft's LAN search (UDP :19132) so worlds we joined show up under Play > Friends.
 * [entries] returns (serverGuid, motd) for every world to advertise.
 */
class LanAdvertiser(private val entries: () -> List<Pair<Long, String>>) {
    @Volatile private var run = false
    private var sock: DatagramSocket? = null

    fun start(): Boolean {
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            s.broadcast = true
            s.bind(InetSocketAddress(19132))
            s.soTimeout = 1000
            sock = s
        } catch (e: Exception) {
            return false
        }
        run = true
        Thread { loop() }.start()
        return true
    }

    private fun loop() {
        val buf = ByteArray(2048)
        while (run) {
            try {
                val p = DatagramPacket(buf, buf.size)
                sock!!.receive(p)
                if (Rak.isPing(buf, p.length)) {
                    for (e in entries()) {
                        val pong = Rak.pong(buf, e.first, e.second)
                        sock!!.send(DatagramPacket(pong, pong.size, p.socketAddress))
                    }
                }
            } catch (e: SocketTimeoutException) {
            } catch (e: Exception) {
                if (run) sleepMs(200)
            }
        }
    }

    fun stop() {
        run = false
        try {
            sock?.close()
        } catch (e: Exception) {
        }
    }
}
