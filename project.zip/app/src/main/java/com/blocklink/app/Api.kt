package com.blocklink.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class Api(private val host: String, private val port: Int = 9000) {
    private var sock: Socket? = null
    private var out: OutputStream? = null
    private val replies = LinkedBlockingQueue<JSONObject>()
    @Volatile var onEvent: ((JSONObject) -> Unit)? = null

    fun connect() {
        val s = Socket()
        s.connect(InetSocketAddress(host, port), 8000)
        sock = s
        out = s.getOutputStream()
        val rd = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
        Thread {
            try {
                while (true) {
                    val line = rd.readLine() ?: break
                    val m = JSONObject(line)
                    if (m.has("ev")) onEvent?.invoke(m) else replies.put(m)
                }
            } catch (_: Exception) {
            }
            replies.put(JSONObject().put("ok", false).put("err", "connection closed"))
        }.apply { isDaemon = true }.start()
    }

    @Synchronized
    fun call(o: JSONObject): JSONObject {
        replies.clear()
        out!!.write((o.toString() + "\n").toByteArray(Charsets.UTF_8))
        out!!.flush()
        return replies.poll(10, TimeUnit.SECONDS) ?: JSONObject().put("ok", false).put("err", "timeout")
    }

    fun close() {
        try { sock?.close() } catch (_: Exception) {}
    }
}
