package com.blocklink.app

import android.content.res.Resources
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManagerFactory

/** TLS connection to the BlockLink server. Trusts only the certificate bundled in res/raw/server_cert.pem */
class Api(server: String, private val res: Resources) {
    val host: String
    val port: Int

    init {
        val s = server.trim()
        val i = s.lastIndexOf(':')
        if (i > 0 && i < s.length - 1 && s.substring(i + 1).all { it.isDigit() }) {
            host = s.substring(0, i)
            port = s.substring(i + 1).toInt()
        } else {
            host = s
            port = 9000
        }
    }

    private var sock: SSLSocket? = null
    private var out: OutputStream? = null
    private val pending = ConcurrentHashMap<Int, LinkedBlockingQueue<JSONObject>>()
    private val ids = AtomicInteger(1)

    @Volatile
    var alive = false
    var onEvent: ((JSONObject) -> Unit)? = null
    var onClose: (() -> Unit)? = null

    fun connect(): Boolean {
        return try {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = res.openRawResource(R.raw.server_cert).use { cf.generateCertificate(it) }
            val ks = KeyStore.getInstance(KeyStore.getDefaultType())
            ks.load(null, null)
            ks.setCertificateEntry("server", cert)
            val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            tmf.init(ks)
            val sslCtx = SSLContext.getInstance("TLS")
            sslCtx.init(null, tmf.trustManagers, null)
            val s = sslCtx.socketFactory.createSocket() as SSLSocket
            s.connect(InetSocketAddress(host, port), 8000)
            s.soTimeout = 8000
            s.startHandshake()
            s.soTimeout = 0
            s.keepAlive = true
            sock = s
            out = s.outputStream
            alive = true
            startReader(s)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun startReader(s: SSLSocket) {
        Thread {
            try {
                val br = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8), 65536)
                while (true) {
                    val line = br.readLine() ?: break
                    val j = try {
                        JSONObject(line)
                    } catch (e: Exception) {
                        null
                    }
                    if (j == null) continue
                    if (j.has("ev")) {
                        onEvent?.invoke(j)
                    } else {
                        pending[j.optInt("id", -1)]?.offer(j)
                    }
                }
            } catch (e: Exception) {
            }
            alive = false
            for (q in pending.values) q.offer(errJson("ขาดการเชื่อมต่อเซิร์ฟเวอร์"))
            onClose?.invoke()
        }.start()
    }

    fun call(op: String, args: JSONObject = JSONObject(), timeoutMs: Long = 20000): JSONObject {
        if (!alive) return errJson("ไม่ได้เชื่อมต่อเซิร์ฟเวอร์")
        val id = ids.getAndIncrement()
        val q = LinkedBlockingQueue<JSONObject>()
        pending[id] = q
        try {
            args.put("op", op)
            args.put("id", id)
            val data = (args.toString() + "\n").toByteArray(Charsets.UTF_8)
            synchronized(this) {
                val o = out
                if (o == null) return errJson("ไม่ได้เชื่อมต่อเซิร์ฟเวอร์")
                o.write(data)
                o.flush()
            }
            return q.poll(timeoutMs, TimeUnit.MILLISECONDS) ?: errJson("หมดเวลา เซิร์ฟเวอร์ตอบไม่ทัน")
        } catch (e: Exception) {
            return errJson("ส่งข้อมูลไม่สำเร็จ")
        } finally {
            pending.remove(id)
        }
    }

    fun close() {
        alive = false
        try {
            sock?.close()
        } catch (e: Exception) {
        }
    }
}
