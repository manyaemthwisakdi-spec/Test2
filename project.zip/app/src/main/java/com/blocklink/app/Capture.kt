package com.blocklink.app

import android.app.Activity
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/** Transparent activity that shows Android's "start recording / casting" consent and then starts CaptureService. */
class CaptureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 77)
        } catch (e: Exception) {
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
            i.putExtra("rc", resultCode)
            i.putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        finish()
    }
}

/**
 * Takes a small still picture of the screen every ~2.5 s while the owner is hosting and uploads it.
 * On Android 14+ pick "a single app" (Minecraft) in the consent window so notifications are not captured.
 */
class CaptureService : Service() {
    companion object {
        @Volatile
        var running = false

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, CaptureService::class.java))
        }
    }

    private var mp: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var ht: HandlerThread? = null
    @Volatile private var alive = false

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun notif(): Notification {
        LinkService.ensureChannels(this)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, LinkService.CH) else Notification.Builder(this)
        return b.setSmallIcon(R.drawable.ic_stat).setContentTitle("Block Link")
            .setContentText("กำลังส่งภาพโลกให้เพื่อนดู").setOngoing(true).build()
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val rc = intent?.getIntExtra("rc", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        val n = notif()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2, n)
        }
        if (data == null || rc == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        var m: MediaProjection? = null
        try {
            m = mpm.getMediaProjection(rc, data)
        } catch (e: Exception) {
        }
        if (m == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        mp = m
        val t = HandlerThread("bl-capture")
        t.start()
        ht = t
        val handler = Handler(t.looper)
        m.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, handler)

        val dm = resources.displayMetrics
        val big = Math.max(dm.widthPixels, dm.heightPixels)
        val small = Math.min(dm.widthPixels, dm.heightPixels)
        val w = 640
        val hh = Math.max(2, (640f * small / big).toInt())
        try {
            val rd = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
            reader = rd
            vd = m.createVirtualDisplay("blcap", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        alive = true
        running = true
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!alive) return
                grab(w, hh)
                if (alive) handler.postDelayed(this, 2500)
            }
        }, 1500)
        return START_NOT_STICKY
    }

    private fun grab(w: Int, hh: Int) {
        if (!Core.hosting) {
            stopSelf()
            return
        }
        val rd = reader ?: return
        var img: android.media.Image? = null
        try {
            img = rd.acquireLatestImage()
        } catch (e: Exception) {
        }
        if (img == null) return
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * w
            val bmp = Bitmap.createBitmap(w + rowPad / p.pixelStride, hh, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            val crop = Bitmap.createBitmap(bmp, 0, 0, w, hh)
            val bo = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 55, bo)
            val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            Core.api?.call("snap_put", JSONObject().put("jpg", b64), 15000)
        } catch (e: Exception) {
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        alive = false
        running = false
        try {
            vd?.release()
        } catch (e: Exception) {
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        try {
            mp?.stop()
        } catch (e: Exception) {
        }
        try {
            ht?.quitSafely()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
