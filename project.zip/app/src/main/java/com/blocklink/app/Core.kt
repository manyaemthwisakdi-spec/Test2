package com.blocklink.app

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class BlApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Core.init(this)
    }
}

/** A world of another account that this phone advertises to Minecraft (Play > Friends). */
class Joined(
    val hostUid: String,
    val sid: String,
    val port: Int,
    val guid: Long,
    @Volatile var motd: String,
    val world: String,
    val version: String,
    val hostName: String,
    val hostHandle: String,
    val proxy: JoinerProxy
)

object Core {
    lateinit var app: Context

    @Volatile var api: Api? = null
    @Volatile var me: JSONObject? = null
    @Volatile var wantOnline = false
    @Volatile var uiVisible = false
    private var reconnecting = false

    val main = Handler(Looper.getMainLooper())
    val listeners = CopyOnWriteArrayList<(JSONObject) -> Unit>()

    // --- sharing state (shared by MainActivity and LinkService)
    @Volatile var playMode = false
    @Volatile var hosting = false
    @Volatile var hostMode = "friends"
    @Volatile var hostWorld = ""
    @Volatile var hostVersion = ""
    @Volatile var hostMotd = ""
    @Volatile var pendingSetup: JSONObject? = null
    val joined = ConcurrentHashMap<String, Joined>()

    fun init(c: Context) {
        app = c.applicationContext
    }

    private fun prefs() = app.getSharedPreferences("bl", Context.MODE_PRIVATE)

    var server: String
        get() = prefs().getString("server", "") ?: ""
        set(v) {
            prefs().edit().putString("server", v.trim()).apply()
        }

    var token: String
        get() = prefs().getString("token", "") ?: ""
        set(v) {
            prefs().edit().putString("token", v).apply()
        }

    var gamePort: Int
        get() = prefs().getInt("gameport", 19132)
        set(v) {
            prefs().edit().putInt("gameport", v).apply()
        }

    var overlayAsked: Boolean
        get() = prefs().getBoolean("overlay_asked", false)
        set(v) {
            prefs().edit().putBoolean("overlay_asked", v).apply()
        }

    val uid: String get() = me?.optString("uid") ?: ""

    /** host part of the server setting */
    fun relayHost(): String {
        val s = server.trim()
        val i = s.lastIndexOf(':')
        return if (i > 0 && i < s.length - 1 && s.substring(i + 1).all { it.isDigit() }) s.substring(0, i) else s
    }

    fun relayUdpPort(): Int {
        val s = server.trim()
        val i = s.lastIndexOf(':')
        val tcp = if (i > 0 && i < s.length - 1 && s.substring(i + 1).all { it.isDigit() }) s.substring(i + 1).toInt() else 9000
        return tcp + 1
    }

    fun dispatch(ev: JSONObject) {
        main.post {
            for (l in listeners) {
                try {
                    l(ev)
                } catch (e: Exception) {
                }
            }
        }
    }

    fun dispatch(name: String) {
        dispatch(JSONObject().put("ev", name))
    }

    /** Connect (and resume the session if we have a token). Blocking - call off the main thread. */
    @Synchronized
    fun ensure(): Api? {
        val a = api
        if (a != null && a.alive) return a
        val s = server.trim()
        if (s.isEmpty()) return null
        val n = Api(s, app.resources)
        if (!n.connect()) return null
        n.onEvent = { ev -> dispatch(ev) }
        n.onClose = { onApiClosed(n) }
        api = n
        if (token.isNotEmpty() && wantOnline) {
            val r = n.call("resume", JSONObject().put("token", token))
            if (r.optBoolean("ok")) {
                me = r.optJSONObject("me")
            } else if (r.optString("code") == "auth") {
                token = ""
                me = null
                wantOnline = false
                dispatch("session_expired")
            }
        }
        return n
    }

    fun call(op: String, args: JSONObject = JSONObject()): JSONObject {
        val a = ensure() ?: return errJson("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจสอบที่อยู่เซิร์ฟเวอร์และอินเทอร์เน็ต")
        return a.call(op, args)
    }

    private fun onApiClosed(a: Api) {
        if (api !== a) return
        if (!wantOnline) return
        startReconnect()
    }

    @Synchronized
    private fun startReconnect() {
        if (reconnecting) return
        reconnecting = true
        Thread {
            while (wantOnline) {
                try {
                    Thread.sleep(4000)
                } catch (e: Exception) {
                }
                val a = ensure()
                if (a != null && a.alive && me != null) {
                    dispatch("reconnected")
                    break
                }
            }
            reconnecting = false
        }.start()
    }

    fun onAuthed(r: JSONObject) {
        token = r.optString("token")
        me = r.optJSONObject("me")
        wantOnline = true
        LinkService.start(app)
    }

    fun logout() {
        val t = token
        val a = api
        wantOnline = false
        token = ""
        me = null
        playMode = false
        hosting = false
        pendingSetup = null
        Thread {
            try {
                a?.call("logout", JSONObject().put("token", t), 5000)
            } catch (e: Exception) {
            }
            a?.close()
        }.start()
        api = null
        LinkService.stop(app)
    }
}
