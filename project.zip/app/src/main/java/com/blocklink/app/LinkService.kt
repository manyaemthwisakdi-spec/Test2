package com.blocklink.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONObject
import java.util.Random

/**
 * Keeps BlockLink alive while Minecraft is in front:
 *  - server connection + notifications
 *  - host side: watches the local game, shows the setup window, bridges UDP to the relay
 *  - joiner side: answers Minecraft's LAN search so joined worlds show up in Play > Friends
 */
class LinkService : Service() {

    companion object {
        const val CH = "bl_main"
        const val CH2 = "bl_alert"

        @Volatile
        var inst: LinkService? = null

        fun start(ctx: Context) {
            val i = Intent(ctx, LinkService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LinkService::class.java))
        }

        fun ensureChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Block Link ทำงานอยู่", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH2, "แจ้งเตือน", NotificationManager.IMPORTANCE_HIGH))
        }

        fun launchMinecraft(ctx: Context): Boolean {
            val pm = ctx.packageManager
            for (p in arrayOf("com.mojang.minecraftpe", "com.mojang.minecrafttrialpe")) {
                val i = pm.getLaunchIntentForPackage(p)
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                    return true
                }
            }
            return false
        }
    }

    private val h = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var bridge: HostBridge? = null
    private var adv: LanAdvertiser? = null
    private var wake: PowerManager.WakeLock? = null
    private var mcast: WifiManager.MulticastLock? = null
    private var overlay: View? = null

    @Volatile private var lastPong = 0L
    @Volatile private var declined = false
    @Volatile private var setupShown = false

    private val evListener: (JSONObject) -> Unit = { ev -> bg { handleEvent(ev) } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Core.init(applicationContext)
        inst = this
        ensureChannels(this)
        goForeground(statusText())
        Core.listeners.add(evListener)
        running = true
        Thread { pingLoop() }.start()
        Thread { watchLoop() }.start()
        Thread { pollLoop() }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Core.token.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Core.wantOnline) {
            Core.wantOnline = true
            bg { Core.ensure() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        inst = null
        Core.listeners.remove(evListener)
        for (j in Core.joined.values.toList()) j.proxy.stop()
        Core.joined.clear()
        adv?.stop()
        adv = null
        bridge?.stop()
        bridge = null
        CaptureService.stop(this)
        Core.hosting = false
        Core.playMode = false
        h.post { hideOverlay() }
        try {
            wake?.release()
        } catch (e: Exception) {
        }
        try {
            mcast?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ helpers
    private fun bg(f: () -> Unit) {
        Thread {
            try {
                f()
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun toast(msg: String) {
        h.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    @Suppress("DEPRECATION")
    private fun builder(channel: String): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
    }

    private fun appIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun mainNotif(text: String): Notification {
        return builder(CH).setSmallIcon(R.drawable.ic_stat).setContentTitle("Block Link")
            .setContentText(text).setContentIntent(appIntent()).setOngoing(true).build()
    }

    private fun goForeground(text: String) {
        val n = mainNotif(text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }

    private fun statusText(): String {
        return when {
            Core.hosting -> "กำลังแชร์โลก: " + Core.hostWorld
            Core.playMode -> "รอคุณเข้าโลก (เปิดเกมผู้เล่นหลายคน)"
            Core.joined.isNotEmpty() -> "โลกของเพื่อนอยู่ใน Minecraft > Play > Friends"
            else -> "เชื่อมต่ออยู่"
        }
    }

    private fun updateNotif() {
        try {
            getSystemService(NotificationManager::class.java).notify(1, mainNotif(statusText()))
        } catch (e: Exception) {
        }
    }

    private fun alertNotif(id: Int, title: String, text: String) {
        if (Core.uiVisible) return
        try {
            val n = builder(CH2).setSmallIcon(R.drawable.ic_stat).setContentTitle(title)
                .setContentText(text).setContentIntent(appIntent()).setAutoCancel(true).build()
            getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) {
        }
    }

    private fun updateLocks() {
        val need = Core.playMode || Core.hosting || Core.joined.isNotEmpty()
        try {
            if (need) {
                if (wake == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "blocklink:svc")
                    w.setReferenceCounted(false)
                    w.acquire(12 * 3600 * 1000L)
                    wake = w
                }
                if (mcast == null) {
                    val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val m = wm.createMulticastLock("blocklink")
                    m.setReferenceCounted(false)
                    m.acquire()
                    mcast = m
                }
            } else {
                wake?.release()
                wake = null
                mcast?.release()
                mcast = null
            }
        } catch (e: Exception) {
        }
        updateNotif()
    }

    // ------------------------------------------------------------ loops
    private fun pingLoop() {
        var n = 0
        while (running) {
            sleepMs(1000)
            n++
            if (n % 25 == 0 && Core.wantOnline) Core.call("ping")
        }
    }

    private fun watchLoop() {
        while (running) {
            sleepMs(2500)
            if (!Core.playMode) continue
            val raw = Rak.probe(Core.gamePort)
            val now = System.currentTimeMillis()
            var mine = false
            if (raw != null) {
                val guid = raw.split(";").getOrElse(6) { "" }
                mine = Core.joined.values.any { it.guid.toString() == guid }
            }
            if (raw != null && raw.startsWith("MCPE") && !mine) {
                lastPong = now
                Core.hostMotd = raw
                if (!Core.hosting && !declined && !setupShown) {
                    val f = raw.split(";")
                    val world = f.getOrElse(7) { "" }.ifEmpty { "My World" }
                    val ver = f.getOrElse(3) { "" }
                    onWorldDetected(world, ver, raw)
                }
            } else if (now - lastPong > 12000) {
                if (Core.hosting) stopHosting(true)
                if (setupShown || declined) {
                    declined = false
                    setupShown = false
                    Core.pendingSetup = null
                    h.post { hideOverlay() }
                }
            }
        }
    }

    private fun pollLoop() {
        var n = 0
        while (running) {
            sleepMs(1000)
            n++
            if (n % 6 != 0 || !Core.wantOnline) continue
            for (j in Core.joined.values.toList()) {
                val r = Core.call("room_status", JSONObject().put("host", j.hostUid))
                if (r.optBoolean("ok")) {
                    if (!r.optBoolean("alive")) {
                        removeJoined(j.hostUid, false)
                        Core.dispatch("joined_changed")
                    } else {
                        val m = r.optString("motd")
                        if (m.isNotEmpty()) j.motd = m
                    }
                }
            }
            if (Core.hosting) {
                val r = Core.call("host_update", JSONObject().put("mode", Core.hostMode).put("motd", Core.hostMotd))
                if (!r.optBoolean("ok") && r.optString("code") == "noroom") {
                    restartRoom()
                } else if (r.optBoolean("ok")) {
                    syncPlayers()
                }
            }
        }
    }

    // ------------------------------------------------------------ events
    private fun handleEvent(ev: JSONObject) {
        val from = ev.optJSONObject("from")?.optString("username") ?: ""
        when (ev.optString("ev")) {
            "friend_req" -> alertNotif(10, "คำขอเป็นเพื่อน", "$from ขอเป็นเพื่อนกับคุณ")
            "friend_ok" -> alertNotif(11, "เป็นเพื่อนกันแล้ว", "$from ตอบรับคำขอของคุณ")
            "msg" -> alertNotif(12, "ข้อความใหม่", ev.optString("text"))
            "join" -> {
                bridge?.add(ev.optString("sid"))
                alertNotif(13, "มีคนเข้าโลกของคุณ", ev.optJSONObject("user")?.optString("username") ?: "")
            }
            "leave" -> bridge?.remove(ev.optString("sid"))
            "kicked" -> {
                removeJoined(ev.optString("host"), false)
                alertNotif(14, "คุณถูกเตะออกจากโลก", "")
                Core.dispatch("joined_changed")
            }
            "room_closed" -> {
                removeJoined(ev.optString("host"), false)
                Core.dispatch("joined_changed")
            }
            "reconnected" -> {
                if (Core.hosting) {
                    val r = Core.call("host_update", JSONObject().put("mode", Core.hostMode))
                    if (!r.optBoolean("ok") && r.optString("code") == "noroom") restartRoom()
                }
            }
        }
    }

    // ------------------------------------------------------------ host side
    private fun onWorldDetected(world: String, ver: String, raw: String) {
        setupShown = true
        Core.pendingSetup = JSONObject().put("world", world).put("version", ver).put("motd", raw)
        h.post {
            if (Core.uiVisible) {
                Core.dispatch("setup_ready")
            } else if (Settings.canDrawOverlays(this)) {
                showOverlay(world, ver)
            } else {
                alertNotif(20, "โลกของคุณพร้อมแล้ว", "แตะเพื่อเลือกว่าจะให้ใครเข้าได้")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun showOverlay(world: String, ver: String) {
        hideOverlay()
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = hostSetupView(this, world, ver, "friends", "ตกลง", { mode ->
                hideOverlay()
                beginHosting(mode)
            }, {
                declined = true
                Core.pendingSetup = null
                hideOverlay()
            })
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val w = Math.min(dp(360), resources.displayMetrics.widthPixels - dp(24))
            val lp = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.CENTER
            wm.addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            alertNotif(20, "โลกของคุณพร้อมแล้ว", "แตะเพื่อเลือกว่าจะให้ใครเข้าได้")
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    /** Called from the overlay or from MainActivity once the owner chose a mode. */
    fun beginHosting(mode: String) {
        val ps = Core.pendingSetup ?: return
        bg {
            val args = JSONObject().put("world", ps.optString("world")).put("version", ps.optString("version"))
                .put("mode", mode).put("motd", ps.optString("motd"))
            val r = Core.call("host_start", args)
            if (!r.optBoolean("ok")) {
                toast(r.optString("err"))
                setupShown = false
                return@bg
            }
            Core.hosting = true
            Core.hostMode = mode
            Core.hostWorld = ps.optString("world")
            Core.hostVersion = ps.optString("version")
            Core.hostMotd = ps.optString("motd")
            Core.pendingSetup = null
            val b = HostBridge(Core.relayHost(), Core.relayUdpPort(), Core.gamePort)
            b.start()
            bridge?.stop()
            bridge = b
            syncPlayers()
            updateLocks()
            Core.dispatch("hosting_changed")
            h.post {
                try {
                    val i = Intent(this, CaptureActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    toast("เปิดหน้าขอแชร์ภาพหน้าจอไม่สำเร็จ")
                }
            }
        }
    }

    private fun restartRoom() {
        val args = JSONObject().put("world", Core.hostWorld).put("version", Core.hostVersion)
            .put("mode", Core.hostMode).put("motd", Core.hostMotd)
        Core.call("host_start", args)
    }

    private fun syncPlayers() {
        val r = Core.call("players")
        if (!r.optBoolean("ok")) return
        val sids = ArrayList<String>()
        for (p in r.optJSONArray("players").objs()) sids.add(p.optString("sid"))
        bridge?.sync(sids)
    }

    /** Non-blocking. */
    fun stopHosting(tell: Boolean) {
        Core.hosting = false
        val b = bridge
        bridge = null
        b?.stop()
        CaptureService.stop(this)
        if (tell) bg { Core.call("host_stop") }
        Core.dispatch("hosting_changed")
        updateLocks()
    }

    /** Called by the UI after Core.playMode was switched. */
    fun onPlayChanged() {
        if (!Core.playMode) {
            declined = false
            setupShown = false
            lastPong = 0L
            Core.pendingSetup = null
            h.post { hideOverlay() }
            if (Core.hosting) stopHosting(true)
        }
        updateLocks()
        Core.dispatch("hosting_changed")
    }

    fun declineSetup() {
        declined = true
        Core.pendingSetup = null
    }

    // ------------------------------------------------------------ joiner side
    /** 0 = ok, 1 = could not start proxy, 2 = proxy ok but UDP 19132 busy (Friends list won't show it). Blocking-free. */
    fun addJoined(r: JSONObject): Int {
        val hostUid = r.optString("host")
        val hi = r.optJSONObject("hostinfo")
        val existing = Core.joined[hostUid]
        if (existing != null) {
            existing.motd = r.optString("motd")
            return startAdv()
        }
        var port = 19200
        while (Core.joined.values.any { it.port == port }) port++
        val proxy = JoinerProxy(Core.relayHost(), Core.relayUdpPort(), r.optString("sid"), port)
        if (!proxy.start()) return 1
        val guid = Random().nextLong() and Long.MAX_VALUE
        val j = Joined(hostUid, r.optString("sid"), port, guid, r.optString("motd"), r.optString("world"),
            r.optString("version"), hi?.optString("username") ?: "", hi?.optString("handle") ?: "", proxy)
        Core.joined[hostUid] = j
        updateLocks()
        return startAdv()
    }

    @Synchronized
    private fun startAdv(): Int {
        if (adv != null) return 0
        val a = LanAdvertiser {
            Core.joined.values.map { j -> Pair(j.guid, Rak.rewriteMotd(j.motd, j.hostName, j.guid, j.port)) }
        }
        return if (a.start()) {
            adv = a
            0
        } else {
            2
        }
    }

    /** If [tell] is true this makes a network call - run it off the main thread. */
    fun removeJoined(hostUid: String, tell: Boolean) {
        val j = Core.joined.remove(hostUid) ?: return
        j.proxy.stop()
        if (tell) Core.call("leave", JSONObject().put("sid", j.sid))
        if (Core.joined.isEmpty()) {
            adv?.stop()
            adv = null
        }
        updateLocks()
    }
}
