package com.blocklink.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/** State while creating an account (after the email was verified). */
class Setup(val ticket: String) {
    var avatar = ""
    var username = ""
}

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private val hd = Handler(Looper.getMainLooper())
    private val stack = ArrayList<Pair<String, () -> View>>()
    private var screen = ""
    private var tick = 0
    private var photoCb: ((String) -> Unit)? = null
    private var chatWith = ""
    private var chatBox: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var dialogOpen = false
    private var probeView: android.widget.TextView? = null

    private val listener: (JSONObject) -> Unit = { ev -> onEv(ev) }

    // ================================================================ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Core.init(applicationContext)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        root = FrameLayout(this)
        root.setBackgroundColor(C.BG)
        setContentView(root)
        if (Core.token.isNotEmpty()) {
            if (Core.me != null && Core.wantOnline) goTab("home") else startSession()
        } else {
            go("welcome") { welcomeView() }
        }
    }

    override fun onResume() {
        super.onResume()
        Core.uiVisible = true
        Core.listeners.add(listener)
        if (Core.pendingSetup != null && !Core.hosting && Core.me != null) showSetupDialog()
    }

    override fun onPause() {
        super.onPause()
        Core.uiVisible = false
        Core.listeners.remove(listener)
    }

    override fun onBackPressed() {
        if (stack.size > 1) back() else super.onBackPressed()
    }

    // ================================================================ helpers
    private fun bg(f: () -> Unit) {
        Thread {
            try {
                f()
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun ui(f: () -> Unit) {
        runOnUiThread { f() }
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun call(op: String, args: JSONObject = JSONObject(), cb: (JSONObject) -> Unit) {
        bg {
            val r = Core.call(op, args)
            ui { cb(r) }
        }
    }

    private fun render(b: () -> View) {
        tick++
        val v = b()
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun go(name: String, b: () -> View) {
        stack.add(Pair(name, b))
        screen = name
        render(b)
    }

    private fun goTab(name: String) {
        stack.clear()
        when (name) {
            "search" -> go("search") { tabPage("search", searchView()) }
            "chat" -> go("chat") { tabPage("chat", chatListView()) }
            else -> go("home") { tabPage("home", homeView()) }
        }
    }

    private fun back() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            val t = stack[stack.size - 1]
            screen = t.first
            render(t.second)
        }
    }

    private fun reload() {
        if (stack.isNotEmpty()) render(stack[stack.size - 1].second)
    }

    private fun every(ms: Long, f: () -> Unit) {
        val id = tick
        val r = object : Runnable {
            override fun run() {
                if (id != tick || isFinishing) return
                f()
                hd.postDelayed(this, ms)
            }
        }
        hd.postDelayed(r, ms)
    }

    private fun scroll(c: View): View {
        val sv = ScrollView(this)
        sv.setBackgroundColor(C.BG)
        sv.isFillViewport = true
        sv.addView(c, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun topBar(title: String, canBack: Boolean): View {
        val bar = hbox()
        bar.setPadding(dp(8), dp(10), dp(12), dp(10))
        bar.setBackgroundColor(C.CARD)
        if (canBack) {
            val b = tv("←", 22f, C.WHITE, true)
            b.setPadding(dp(12), 0, dp(12), 0)
            b.setOnClickListener { back() }
            bar.addView(b)
        }
        bar.addView(tv(title, 18f, C.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        return bar
    }

    private fun page(title: String, body: View): View {
        val col = vbox()
        col.setBackgroundColor(C.BG)
        col.addView(topBar(title, true), LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    private fun navBar(tab: String): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.CARD)
        bar.setPadding(0, dp(6), 0, dp(6))
        fun item(id: String, icon: String, label: String) {
            val t = tv(icon + "\n" + label, 12f, if (id == tab) C.PINK else C.MUTED, id == tab)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { goTab(id) }
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        item("home", "🏠", "หน้าแรก")
        item("search", "🔎", "ค้นหา")
        item("chat", "💬", "แชท")
        return bar
    }

    private fun tabPage(tab: String, content: View): View {
        val col = vbox()
        col.setBackgroundColor(C.BG)
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(navBar(tab), LinearLayout.LayoutParams(MATCH, WRAP))
        return col
    }

    private fun askText(title: String, hint: String, init: String, maxLen: Int, filter: InputFilter?, ok: (String) -> Unit) {
        val e = input(hint, false, maxLen)
        e.setText(init)
        if (filter != null) e.filters = arrayOf(filter, InputFilter.LengthFilter(maxLen))
        val box = LinearLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(e)
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("ตกลง") { _, _ -> ok(e.text.toString().trim()) }
            .setNegativeButton("ยกเลิก", null).show()
    }

    private fun requireServer(next: () -> Unit) {
        if (Core.server.isEmpty()) {
            toast("ตั้งที่อยู่เซิร์ฟเวอร์ก่อนนะ")
            serverDialog { next() }
        } else {
            next()
        }
    }

    private fun serverDialog(done: () -> Unit) {
        askText("ที่อยู่เซิร์ฟเวอร์", "เช่น 203.0.113.5 หรือ game.example.com", Core.server, 100, null) { v ->
            if (v.isNotEmpty()) {
                Core.server = v
                done()
            }
        }
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 5)
        }
    }

    private fun afterAuth() {
        askNotifPermission()
        goTab("home")
    }

    private fun startSession() {
        go("loading") { loadingView("กำลังเชื่อมต่อ...") }
        Core.wantOnline = true
        bg {
            Core.ensure()
            ui {
                if (Core.me != null) {
                    LinkService.start(this)
                    askNotifPermission()
                    goTab("home")
                } else if (Core.token.isEmpty()) {
                    stack.clear()
                    go("welcome") { welcomeView() }
                } else {
                    go("offline") { offlineView() }
                }
            }
        }
    }

    // ================================================================ events
    private fun onEv(ev: JSONObject) {
        when (ev.optString("ev")) {
            "friend_req" -> {
                toast("มีคำขอเป็นเพื่อนใหม่")
                if (screen == "home" || screen == "requests") reload()
            }
            "friend_ok" -> {
                toast("เป็นเพื่อนกันแล้ว")
                if (screen == "chat") reload()
            }
            "msg" -> {
                if (screen == "chatroom" && chatWith == ev.optString("from")) {
                    addBubble(ev.optString("text"), false)
                } else {
                    toast("💬 " + ev.optString("text"))
                }
            }
            "setup_ready" -> showSetupDialog()
            "probe" -> {
                probeView?.text = "สถานะตรวจเกม: " + Core.probeInfo
            }
            "hosting_changed", "joined_changed" -> {
                if (screen == "home" || screen == "worlds") reload()
            }
            "kicked" -> toast("คุณถูกเตะออกจากโลก")
            "session_expired" -> {
                toast("เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่")
                stack.clear()
                go("welcome") { welcomeView() }
            }
        }
    }

    // ================================================================ simple screens
    private fun loadingView(msg: String): View {
        val c = vbox(24)
        c.gravity = Gravity.CENTER
        c.setBackgroundColor(C.BG)
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        c.addView(logo, LinearLayout.LayoutParams(dp(100), dp(100)))
        c.addView(tv(msg, 15f, C.MUTED))
        return c
    }

    private fun offlineView(): View {
        val c = vbox(24)
        c.addView(gap(40))
        c.addView(tv("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้", 22f, C.WHITE, true))
        c.addView(tv("เซิร์ฟเวอร์: " + Core.server, 13f, C.MUTED))
        c.addView(btn("ลองใหม่") { startSession() })
        c.addView(btn("ตั้งค่าเซิร์ฟเวอร์", 1) { serverDialog { startSession() } })
        c.addView(btn("ออกจากระบบ", 1) {
            Core.logout()
            stack.clear()
            go("welcome") { welcomeView() }
        })
        return scroll(c)
    }

    private fun welcomeView(): View {
        val c = vbox(24)
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(gap(24))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        c.addView(logo, LinearLayout.LayoutParams(dp(130), dp(130)))
        c.addView(gap(10))
        val t = tv("ยินดีต้อนรับสู่ Block link", 24f, C.WHITE, true)
        t.gravity = Gravity.CENTER
        c.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        val s = tv("กรุณาเลือก การลงชื่อเข้าใช้/สมัครบัญชี", 14f, C.MUTED)
        s.gravity = Gravity.CENTER
        c.addView(s, LinearLayout.LayoutParams(MATCH, WRAP))
        c.addView(gap(20))
        c.addView(btn("G    ดำเนินการต่อด้วย Google", 2) {
            toast("การเข้าสู่ระบบด้วย Google จะเปิดใช้ในเวอร์ชันถัดไป ตอนนี้ใช้อีเมลไปก่อนนะ")
        })
        c.addView(btn("✉    อีเมล", 1) { requireServer { go("login") { loginView() } } })
        val sv = if (Core.server.isEmpty()) "⚙ ยังไม่ได้ตั้งเซิร์ฟเวอร์ (แตะเพื่อตั้ง)" else "⚙ เซิร์ฟเวอร์: " + Core.server
        val l = tv(sv, 13f, if (Core.server.isEmpty()) C.PINK else C.MUTED)
        l.gravity = Gravity.CENTER
        l.setPadding(0, dp(20), 0, dp(12))
        l.setOnClickListener { serverDialog { reload() } }
        c.addView(l, LinearLayout.LayoutParams(MATCH, WRAP))
        return scroll(c)
    }

    private fun loginView(): View {
        val c = vbox(24)
        c.addView(tv("เข้าสู่ระบบด้วยอีเมล", 22f, C.WHITE, true))
        c.addView(tv("ใส่อีเมลที่เคยลงชื่อเข้าใช้ไว้แล้ว", 13f, C.MUTED))
        val em = input("อีเมล", false, 0, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pw = input("รหัสผ่าน", true)
        c.addView(em)
        c.addView(pw)
        var busy = false
        c.addView(btn("เข้าสู่ระบบ") {
            val e = em.text.toString().trim()
            val p = pw.text.toString()
            if (busy) return@btn
            if (e.isEmpty() || p.isEmpty()) {
                toast("กรอกอีเมลและรหัสผ่านก่อน")
                return@btn
            }
            busy = true
            call("login", JSONObject().put("email", e).put("password", p)) { r ->
                busy = false
                if (r.optBoolean("ok")) {
                    Core.onAuthed(r)
                    afterAuth()
                } else {
                    toast(r.optString("err"))
                }
            }
        })
        c.addView(gap(6))
        c.addView(link("ไม่มีบัญชีหรอ? สมัครเลย!") { go("signup") { signupEmailView() } })
        return page("", scroll(c))
    }

    private fun signupEmailView(): View {
        val c = vbox(24)
        c.addView(tv("สมัครบัญชีด้วยอีเมล", 22f, C.WHITE, true))
        c.addView(tv("เราจะส่งรหัสยืนยัน 6 หลักไปที่อีเมลนี้ (ต้องเป็นอีเมลที่มีอยู่จริง)", 13f, C.MUTED))
        val em = input("อีเมล", false, 0, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        c.addView(em)
        var busy = false
        c.addView(btn("ตกลง") {
            val e = em.text.toString().trim().lowercase()
            if (busy) return@btn
            if (e.isEmpty()) {
                toast("กรอกอีเมลก่อน")
                return@btn
            }
            busy = true
            call("otp_send", JSONObject().put("email", e)) { r ->
                busy = false
                val code = r.optString("code")
                if (r.optBoolean("ok")) {
                    go("otp") { otpView(e, 60) }
                } else if (code.startsWith("wait")) {
                    go("otp") { otpView(e, code.substring(4).toIntOrNull() ?: 60) }
                } else {
                    toast(r.optString("err"))
                }
            }
        })
        return page("", scroll(c))
    }

    private fun otpView(email: String, startLeft: Int): View {
        val c = vbox(24)
        c.addView(tv("ยืนยันอีเมล", 22f, C.WHITE, true))
        c.addView(tv("เราส่งรหัส 6 หลักไปที่\n" + email + "\nรหัสใช้ได้ครั้งเดียวและหมดอายุใน 24 ชั่วโมง", 13f, C.MUTED))
        val code = input("รหัส 6 หลัก", false, 6, InputType.TYPE_CLASS_NUMBER)
        c.addView(code)
        var busy = false
        var left = startLeft
        val rs = arrayOfNulls<TextView>(1)
        fun refresh() {
            rs[0]?.text = if (left > 0) "ส่งรหัสอีกครั้งได้ใน $left วินาที" else "ส่งรหัสอีกครั้ง"
            rs[0]?.alpha = if (left > 0) 0.5f else 1f
        }
        c.addView(btn("ยืนยัน") {
            val cd = code.text.toString().trim()
            if (busy) return@btn
            if (cd.length != 6) {
                toast("กรอกรหัส 6 หลัก")
                return@btn
            }
            busy = true
            call("otp_verify", JSONObject().put("email", email).put("code", cd)) { r ->
                busy = false
                if (r.optBoolean("ok")) {
                    val st = Setup(r.optString("ticket"))
                    go("photo") { photoView(st) }
                } else {
                    toast(r.optString("err"))
                }
            }
        })
        val resend = btn("", 1) {
            if (left > 0) {
                toast("รอ $left วินาทีก่อนส่งใหม่")
                return@btn
            }
            call("otp_send", JSONObject().put("email", email)) { r ->
                if (r.optBoolean("ok")) {
                    left = 60
                    refresh()
                    toast("ส่งรหัสใหม่แล้ว")
                } else {
                    val cd = r.optString("code")
                    if (cd.startsWith("wait")) {
                        left = cd.substring(4).toIntOrNull() ?: 60
                        refresh()
                    }
                    toast(r.optString("err"))
                }
            }
        }
        rs[0] = resend
        refresh()
        c.addView(resend)
        every(1000) {
            if (left > 0) {
                left--
                refresh()
            }
        }
        return page("", scroll(c))
    }

    // ---------------------------------------------------------------- profile setup
    private fun photoView(st: Setup): View {
        val c = vbox(24)
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(tv("ตั้งรูปโปรไฟล์", 22f, C.WHITE, true))
        c.addView(tv("แตะที่รูปเพื่อเลือก ถ่ายรูป หรือ แกลเลอรี", 13f, C.MUTED))
        c.addView(gap(24))
        val iv = avatarView(st.avatar, 150)
        iv.setOnClickListener {
            pickPhoto { b64 ->
                st.avatar = b64
                val bm = b64Bitmap(b64)
                if (bm != null) iv.setImageBitmap(bm)
            }
        }
        c.addView(iv)
        c.addView(gap(24))
        c.addView(btn("ต่อไป") { go("name") { nameView(st) } })
        return page("", scroll(c))
    }

    private fun nameView(st: Setup): View {
        val c = vbox(24)
        c.addView(tv("ตั้งชื่อผู้ใช้", 22f, C.WHITE, true))
        c.addView(tv("ใช้ได้เฉพาะภาษาไทย ภาษาอังกฤษ ตัวเลข และ _ (สูงสุด 20 ตัว)\nเปลี่ยนได้ 1 ครั้งต่อ 7 วัน", 13f, C.MUTED))
        val nm = input("ชื่อผู้ใช้", false, 20)
        nm.filters = arrayOf(charFilter(true, false), InputFilter.LengthFilter(20))
        nm.setText(st.username)
        c.addView(nm)
        c.addView(btn("ต่อไป") {
            val v = nm.text.toString().trim()
            if (v.isEmpty()) {
                toast("ตั้งชื่อผู้ใช้ก่อน")
            } else {
                st.username = v
                go("handle") { handleView(st) }
            }
        })
        return page("", scroll(c))
    }

    private fun handleView(st: Setup): View {
        val c = vbox(24)
        c.addView(tv("ตั้งชื่อ @ และรหัสผ่าน", 22f, C.WHITE, true))
        c.addView(tv("@ ใช้ a-z ตัวเล็ก ตัวเลข และ _ เท่านั้น ห้ามเว้นวรรค (3-20 ตัว) เปลี่ยนได้ 1 ครั้งต่อ 30 วัน", 13f, C.MUTED))
        val row = hbox()
        row.addView(tv("@", 24f, C.PINK, true))
        val hin = input("ชื่อ @ ของคุณ", false, 20)
        hin.filters = arrayOf(charFilter(false, true), InputFilter.LengthFilter(20))
        row.addView(hin, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(row)
        c.addView(gap(6))
        val pw = input("รหัสผ่าน", true, 64)
        c.addView(pw)
        c.addView(tv("รหัสผ่านอย่างน้อย 8 ตัว ต้องมีตัวเลขและภาษาอังกฤษ ห้ามเว้นวรรค", 12f, C.MUTED))
        var busy = false
        c.addView(btn("ตกลง") {
            val h = hin.text.toString().trim()
            val p = pw.text.toString()
            if (busy) return@btn
            if (!Regex("^[a-z0-9_]{3,20}$").matches(h)) {
                toast("@ ต้องยาว 3-20 ตัว ใช้ a-z ตัวเลข และ _")
                return@btn
            }
            val pe = pwError(p, h)
            if (pe != null) {
                toast(pe)
                return@btn
            }
            busy = true
            val args = JSONObject().put("ticket", st.ticket).put("username", st.username)
                .put("handle", h).put("password", p).put("avatar", st.avatar)
            call("signup", args) { r ->
                busy = false
                if (r.optBoolean("ok")) {
                    Core.onAuthed(r)
                    afterAuth()
                } else {
                    toast(r.optString("err"))
                }
            }
        })
        return page("", scroll(c))
    }

    // ================================================================ photo picking
    private fun pickPhoto(cb: (String) -> Unit) {
        photoCb = cb
        AlertDialog.Builder(this).setTitle("ตั้งรูปโปรไฟล์")
            .setItems(arrayOf("📷  ถ่ายรูป", "🖼  เลือกจากแกลเลอรี")) { _, which ->
                try {
                    if (which == 0) {
                        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 101)
                    } else {
                        val i = Intent(Intent.ACTION_GET_CONTENT)
                        i.type = "image/*"
                        startActivityForResult(i, 102)
                    }
                } catch (e: Exception) {
                    toast("เปิดไม่ได้ ลองอีกวิธีนะ")
                }
            }.show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        var bm: Bitmap? = null
        if (requestCode == 101) {
            bm = data.extras?.get("data") as? Bitmap
        } else if (requestCode == 102) {
            val uri = data.data
            if (uri != null) bm = decodeUri(uri)
        }
        val cb = photoCb
        if (bm != null && cb != null) cb(toAvatarB64(bm))
    }

    private fun decodeUri(uri: Uri): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 512 || o.outHeight / ss > 512) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) {
            null
        }
    }

    private fun toAvatarB64(bm: Bitmap): String {
        val s = Math.min(bm.width, bm.height)
        val sq = Bitmap.createBitmap(bm, (bm.width - s) / 2, (bm.height - s) / 2, s, s)
        val out = Bitmap.createScaledBitmap(sq, 128, 128, true)
        val bo = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    // ================================================================ home
    private fun homeView(): View {
        val c = vbox(16)
        val head = hbox()
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(36), dp(36)))
        head.addView(tv("  Block Link", 20f, C.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val bell = tv("🔔", 22f)
        bell.setPadding(dp(8), dp(4), dp(10), dp(4))
        bell.setOnClickListener { go("requests") { requestsView() } }
        head.addView(bell)
        val av = avatarView(Core.me?.optString("avatar"), 38)
        av.setOnClickListener { go("profile") { profileView() } }
        head.addView(av)
        c.addView(head)
        c.addView(gap(14))

        if (Core.hosting) {
            c.addView(hostCard())
        } else if (Core.playMode) {
            c.addView(playingCard())
        }
        c.addView(gap(6))
        val play = btn("🎮   เล่นเกม!") { playGame() }
        play.textSize = 22f
        play.setPadding(dp(16), dp(24), dp(16), dp(24))
        c.addView(play)
        c.addView(btn("👥   หาเพื่อนเล่น!", 1) { go("worlds") { worldsView() } })

        if (Core.joined.isNotEmpty()) {
            c.addView(gap(16))
            c.addView(tv("โลกที่อยู่ใน Minecraft > Play > Friends ตอนนี้", 14f, C.BLUE, true))
            for (j in Core.joined.values.toList()) c.addView(joinedRow(j))
        }
        call("requests") { r ->
            val n = r.optJSONArray("users").objs().size
            if (n > 0 && screen == "home") bell.text = "🔔 $n"
        }
        return scroll(c)
    }

    private fun joinedRow(j: Joined): View {
        val row = hbox()
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = roundBg(C.CARD, 14)
        val t = tv(j.hostName + "  @" + j.hostHandle + "\n" + j.world, 13f, C.WHITE)
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(smallBtn("ลบออก", 1) { removeJoined(j.hostUid) })
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(8)
        row.layoutParams = p
        return row
    }

    private fun removeJoined(hostUid: String) {
        bg {
            LinkService.inst?.removeJoined(hostUid, true)
            ui {
                toast("ลบออกจากมายคราฟแล้ว (ยังเห็นในแอปอยู่ถ้าเจ้าของโลกยังอยู่ในโลก)")
                reload()
            }
        }
    }

    private fun playingCard(): View {
        val box = vbox(16)
        box.background = roundBg(C.CARD, 18)
        box.addView(tv("⏳ กำลังรอคุณเข้าโลกใน Minecraft", 15f, C.PINK, true))
        box.addView(tv("เข้าโลกของคุณ แล้วเปิด \"เกมผู้เล่นหลายคน\" ในตั้งค่าโลก เมื่อเข้าโลกแล้วจะมีหน้าต่างตั้งค่าขึ้นมา", 12f, C.MUTED))
        val pv = tv("สถานะตรวจเกม: " + (if (Core.probeInfo.isEmpty()) "ยังไม่ได้ตรวจ" else Core.probeInfo), 11f, C.MUTED)
        probeView = pv
        box.addView(pv)
        box.addView(btn("ปิดโหมดเล่น", 1) {
            Core.playMode = false
            LinkService.inst?.onPlayChanged()
            reload()
        })
        return box
    }

    private fun hostCard(): View {
        val box = vbox(16)
        box.background = roundBg(C.CARD, 18)
        box.addView(tv("🌍 โลกของคุณกำลังแชร์อยู่", 16f, C.GREEN, true))
        box.addView(tv(Core.hostWorld + "  •  " + Core.hostVersion, 14f, C.WHITE))
        box.addView(tv(if (Core.hostMode == "all") "ทุกคนเข้าได้ (รวมเพื่อน)" else "เฉพาะเพื่อนเท่านั้น", 13f, C.BLUE))
        box.addView(gap(6))
        val players = vbox()
        box.addView(players)
        fun loadPlayers() {
            call("players") { r ->
                if (screen == "home") {
                    players.removeAllViews()
                    val lst = r.optJSONArray("players").objs()
                    if (lst.isEmpty()) {
                        players.addView(tv("ยังไม่มีคนเข้าโลก", 12f, C.MUTED))
                    } else {
                        for (p in lst) players.addView(playerRow(p) { loadPlayers() })
                    }
                }
            }
        }
        loadPlayers()
        every(4000) { loadPlayers() }
        val row = hbox()
        row.setPadding(0, dp(10), 0, 0)
        row.addView(smallBtn("เปลี่ยนโหมด") { modeDialog() })
        val sp = View(this)
        row.addView(sp, LinearLayout.LayoutParams(dp(8), 1))
        row.addView(smallBtn("หยุดแชร์", 1) {
            LinkService.inst?.stopHosting(true)
            Core.playMode = false
            LinkService.inst?.onPlayChanged()
            reload()
        })
        box.addView(row)
        return box
    }

    private fun playerRow(p: JSONObject, refresh: () -> Unit): View {
        val u = p.optJSONObject("user") ?: JSONObject()
        val row = hbox()
        row.setPadding(0, dp(4), 0, dp(4))
        row.addView(avatarView(u.optString("avatar"), 32))
        val dot = if (p.optBoolean("live")) "🟢 " else "⚪ "
        val t = tv("  " + dot + u.optString("username") + "  @" + u.optString("handle"), 13f, C.WHITE)
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(smallBtn("เตะ", 1) {
            AlertDialog.Builder(this).setMessage("เตะ " + u.optString("username") + " ออกจากโลก?")
                .setPositiveButton("เตะ") { _, _ ->
                    call("kick", JSONObject().put("sid", p.optString("sid"))) { r ->
                        if (r.optBoolean("ok")) refresh() else toast(r.optString("err"))
                    }
                }.setNegativeButton("ยกเลิก", null).show()
        })
        return row
    }

    private fun showHostDialog(world: String, ver: String, init: String, okText: String,
                               onOk: (String) -> Unit, onSkip: (() -> Unit)?) {
        if (dialogOpen) return
        dialogOpen = true
        val holder = arrayOfNulls<AlertDialog>(1)
        var skipLambda: (() -> Unit)? = null
        if (onSkip != null) {
            skipLambda = {
                holder[0]?.dismiss()
                onSkip()
            }
        }
        val v = hostSetupView(this, world, ver, init, okText, { mode ->
            holder[0]?.dismiss()
            onOk(mode)
        }, skipLambda)
        val d = AlertDialog.Builder(this).setView(v).create()
        d.setCancelable(false)
        d.setOnDismissListener { dialogOpen = false }
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        holder[0] = d
        d.show()
    }

    private fun showSetupDialog() {
        val ps = Core.pendingSetup ?: return
        showHostDialog(ps.optString("world"), ps.optString("version"), "friends", "ตกลง", { mode ->
            LinkService.inst?.beginHosting(mode)
        }, {
            LinkService.inst?.declineSetup()
        })
    }

    private fun modeDialog() {
        showHostDialog(Core.hostWorld, Core.hostVersion, Core.hostMode, "บันทึก", { mode ->
            call("host_update", JSONObject().put("mode", mode)) { r ->
                if (r.optBoolean("ok")) {
                    Core.hostMode = mode
                    reload()
                } else {
                    toast(r.optString("err"))
                }
            }
        }, null)
    }

    private fun playGame() {
        if (!Settings.canDrawOverlays(this) && !Core.overlayAsked) {
            Core.overlayAsked = true
            AlertDialog.Builder(this).setTitle("อนุญาตแสดงทับแอปอื่น")
                .setMessage("เพื่อให้หน้าต่างตั้งค่าโลกโผล่ทับ Minecraft ตอนคุณเข้าโลก ต้องเปิด \"แสดงทับแอปอื่น\" ให้ Block Link (ข้ามได้ จะใช้การแจ้งเตือนแทน)")
                .setPositiveButton("ไปตั้งค่า") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
                }
                .setNegativeButton("ข้ามไปก่อน") { _, _ -> doPlay() }.show()
            return
        }
        doPlay()
    }

    private fun doPlay() {
        Core.playMode = true
        if (LinkService.inst == null) LinkService.start(this)
        LinkService.inst?.onPlayChanged()
        if (LinkService.launchMinecraft(this)) {
            toast("เข้าโลกของคุณ แล้วเปิด \"เกมผู้เล่นหลายคน\" ในตั้งค่าโลก")
        } else {
            toast("ไม่พบ Minecraft ในเครื่องนี้")
        }
    }

    // ================================================================ worlds
    private fun worldsView(): View {
        val c = vbox(12)
        val list = vbox()
        c.addView(list)
        val snaps = HashMap<String, ImageView>()
        val lastTs = HashMap<String, Long>()
        var sig = ""
        var snapBusy = false

        fun loadSnaps() {
            val hosts = snaps.keys.toList()
            if (hosts.isEmpty() || snapBusy) return
            snapBusy = true
            bg {
                for (h in hosts) {
                    val r = Core.call("snap_get", JSONObject().put("host", h).put("since", lastTs[h] ?: 0L))
                    if (r.optBoolean("ok") && !r.optBoolean("same") && r.has("jpg")) {
                        val bm = b64Bitmap(r.optString("jpg"))
                        val ts = r.optLong("ts")
                        ui {
                            if (bm != null) snaps[h]?.setImageBitmap(bm)
                            lastTs[h] = ts
                        }
                    }
                }
                snapBusy = false
            }
        }

        fun renderRooms(rooms: List<JSONObject>) {
            var s = Core.joined.keys.joinToString(",") + "|"
            for (r in rooms) s += r.optString("host") + r.optString("world") + r.optString("mode") + r.optInt("players") + ","
            if (s == sig) return
            sig = s
            list.removeAllViews()
            snaps.clear()
            lastTs.clear()
            if (rooms.isEmpty()) {
                val t = tv("ตอนนี้ยังไม่มีเพื่อนหรือใครเล่นอยู่\nหน้านี้จะอัปเดตเองทุกไม่กี่วินาที", 14f, C.MUTED)
                t.gravity = Gravity.CENTER
                t.setPadding(0, dp(40), 0, 0)
                list.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            } else {
                for (r in rooms) {
                    val p = LinearLayout.LayoutParams(MATCH, WRAP)
                    p.bottomMargin = dp(12)
                    list.addView(roomCard(r, snaps), p)
                }
            }
            loadSnaps()
        }

        fun refresh() {
            call("rooms") { r ->
                if (screen == "worlds" && r.optBoolean("ok")) renderRooms(r.optJSONArray("rooms").objs())
            }
        }
        refresh()
        every(5000) { refresh() }
        every(3000) { loadSnaps() }
        return page("หาเพื่อนเล่น!", scroll(c))
    }

    private fun roomCard(r: JSONObject, snaps: HashMap<String, ImageView>): View {
        val hostUid = r.optString("host")
        val box = vbox(12)
        box.background = roundBg(C.CARD, 18)
        val head = hbox()
        head.addView(avatarView(r.optString("avatar"), 40))
        val names = vbox()
        names.setPadding(dp(10), 0, 0, 0)
        val tag = if (r.optBoolean("friend")) "   ✓ เพื่อน" else ""
        names.addView(tv(r.optString("username") + tag, 16f, C.WHITE, true))
        names.addView(tv("@" + r.optString("handle"), 12f, C.MUTED))
        head.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(head)
        box.addView(gap(6))
        box.addView(tv("🌍 " + r.optString("world") + "  •  " + r.optString("version") + "  •  👥 " + r.optInt("players"), 13f, C.BLUE))
        box.addView(gap(6))
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(C.BLACK)
        iv.setImageResource(R.drawable.logo)
        box.addView(iv, LinearLayout.LayoutParams(MATCH, dp(190)))
        snaps[hostUid] = iv
        val j = Core.joined[hostUid]
        if (j == null) {
            box.addView(btn("🎮  จอย") { joinRoom(r) })
        } else {
            box.addView(tv("✅ อยู่ใน Minecraft > Play > Friends แล้ว", 12f, C.GREEN))
            box.addView(btn("เปิด Minecraft") { LinkService.launchMinecraft(this) })
            box.addView(btn("ลบออกจากมายคราฟ", 1) { removeJoined(hostUid) })
            box.addView(link("เพิ่มเป็นเซิร์ฟเวอร์ (วิธีสำรอง)") { addExternal(j) })
        }
        return box
    }

    private fun joinRoom(r: JSONObject) {
        toast("กำลังเชื่อมต่อ...")
        bg {
            val res = Core.call("join", JSONObject().put("host", r.optString("host")))
            if (!res.optBoolean("ok")) {
                ui { toast(res.optString("err")) }
                return@bg
            }
            val svc = LinkService.inst
            val st = if (svc == null) 1 else svc.addJoined(res)
            ui {
                when (st) {
                    0 -> {
                        toast("เปิด Minecraft > Play > Friends จะเห็นโลกนี้")
                        LinkService.launchMinecraft(this)
                    }
                    2 -> toast("พอร์ต 19132 ถูกใช้อยู่ จึงขึ้นใน Friends ไม่ได้ ใช้ \"เพิ่มเป็นเซิร์ฟเวอร์\" แทน")
                    else -> toast("เริ่มการเชื่อมต่อไม่สำเร็จ")
                }
                reload()
            }
        }
    }

    private fun addExternal(j: Joined) {
        try {
            val u = Uri.parse("minecraft://?addExternalServer=BlockLink-" + j.hostHandle + "|127.0.0.1:" + j.port)
            startActivity(Intent(Intent.ACTION_VIEW, u))
        } catch (e: Exception) {
            toast("เปิดลิงก์ Minecraft ไม่ได้")
        }
    }

    // ================================================================ search / friends
    private fun searchView(): View {
        val c = vbox(16)
        c.addView(tv("ค้นหาเพื่อน", 22f, C.WHITE, true))
        c.addView(tv("พิมพ์ @ ของเพื่อน (แม่นยำที่สุด) หรือชื่อผู้ใช้ ถ้าพิมพ์ผิดจะหาชื่อใกล้เคียงให้", 12f, C.MUTED))
        val q = input("@ชื่อเพื่อน")
        val results = vbox()
        c.addView(q)
        c.addView(btn("ค้นหา") {
            val s = q.text.toString().trim()
            if (s.isEmpty()) {
                toast("พิมพ์ชื่อที่จะค้นหาก่อน")
            } else {
                call("search", JSONObject().put("q", s)) { r ->
                    results.removeAllViews()
                    val lst = r.optJSONArray("users").objs()
                    if (!r.optBoolean("ok")) {
                        toast(r.optString("err"))
                    } else if (lst.isEmpty()) {
                        results.addView(tv("ไม่พบบัญชีที่ตรงกัน", 14f, C.MUTED))
                    } else {
                        for (u in lst) results.addView(userRow(u))
                    }
                }
            }
        })
        c.addView(gap(10))
        c.addView(results)
        return scroll(c)
    }

    private fun userRow(u: JSONObject): View {
        val uid = u.optString("uid")
        val row = hbox()
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = roundBg(C.CARD, 14)
        row.addView(avatarView(u.optString("avatar"), 44))
        val names = vbox()
        names.setPadding(dp(10), 0, 0, 0)
        names.addView(tv(u.optString("username"), 15f, C.WHITE, true))
        names.addView(tv("@" + u.optString("handle"), 12f, C.MUTED))
        row.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        val act = FrameLayout(this)
        fun showRel(rel: String) {
            act.removeAllViews()
            when (rel) {
                "friend" -> act.addView(tv("เพื่อนแล้ว ✓", 13f, C.GREEN))
                "out" -> act.addView(tv("รอตอบรับ", 13f, C.MUTED))
                "in" -> act.addView(smallBtn("ตอบรับ") {
                    call("friend_accept", JSONObject().put("uid", uid)) { r ->
                        if (r.optBoolean("ok")) showRel("friend") else toast(r.optString("err"))
                    }
                })
                else -> act.addView(smallBtn("เพิ่มเพื่อน") {
                    call("friend_add", JSONObject().put("uid", uid)) { r ->
                        if (r.optBoolean("ok")) showRel(r.optString("rel")) else toast(r.optString("err"))
                    }
                })
            }
        }
        showRel(u.optString("rel"))
        row.addView(act)
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(8)
        row.layoutParams = p
        return row
    }

    private fun requestsView(): View {
        val c = vbox(16)
        c.addView(tv("คำขอเป็นเพื่อน", 20f, C.WHITE, true))
        val list = vbox()
        c.addView(list)
        call("requests") { r ->
            val lst = r.optJSONArray("users").objs()
            if (lst.isEmpty()) {
                list.addView(tv("ยังไม่มีคำขอใหม่", 14f, C.MUTED))
            } else {
                for (u in lst) list.addView(requestRow(u))
            }
        }
        return page("แจ้งเตือน", scroll(c))
    }

    private fun requestRow(u: JSONObject): View {
        val uid = u.optString("uid")
        val row = hbox()
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = roundBg(C.CARD, 14)
        row.addView(avatarView(u.optString("avatar"), 44))
        val names = vbox()
        names.setPadding(dp(10), 0, 0, 0)
        names.addView(tv(u.optString("username"), 15f, C.WHITE, true))
        names.addView(tv("@" + u.optString("handle") + " ขอเป็นเพื่อน", 12f, C.MUTED))
        row.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(smallBtn("ตอบรับ") {
            call("friend_accept", JSONObject().put("uid", uid)) { r ->
                if (r.optBoolean("ok")) reload() else toast(r.optString("err"))
            }
        })
        row.addView(View(this), LinearLayout.LayoutParams(dp(6), 1))
        row.addView(smallBtn("ปฏิเสธ", 1) {
            call("friend_decline", JSONObject().put("uid", uid)) { _ -> reload() }
        })
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(8)
        row.layoutParams = p
        return row
    }

    // ================================================================ chat
    private fun chatListView(): View {
        val c = vbox(16)
        c.addView(tv("แชท", 22f, C.WHITE, true))
        val list = vbox()
        c.addView(list)
        call("friends") { r ->
            val lst = r.optJSONArray("friends").objs()
            if (!r.optBoolean("ok")) {
                list.addView(tv(r.optString("err"), 14f, C.MUTED))
            } else if (lst.isEmpty()) {
                list.addView(tv("ยังไม่มีเพื่อน ไปที่แท็บ \"ค้นหา\" เพื่อเพิ่มเพื่อนก่อนนะ", 14f, C.MUTED))
            } else {
                for (f in lst) list.addView(friendRow(f))
            }
        }
        return scroll(c)
    }

    private fun friendRow(f: JSONObject): View {
        val row = hbox()
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.background = roundBg(C.CARD, 14)
        row.addView(avatarView(f.optString("avatar"), 44))
        val names = vbox()
        names.setPadding(dp(10), 0, 0, 0)
        names.addView(tv(f.optString("username"), 15f, C.WHITE, true))
        val st = if (f.optBoolean("room")) "🌍 กำลังเล่นอยู่" else if (f.optBoolean("online")) "ออนไลน์" else "ออฟไลน์"
        names.addView(tv("@" + f.optString("handle") + "  •  " + st, 12f, if (f.optBoolean("online")) C.GREEN else C.MUTED))
        row.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.setOnClickListener { go("chatroom") { chatRoom(f) } }
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(8)
        row.layoutParams = p
        return row
    }

    private fun chatRoom(f: JSONObject): View {
        chatWith = f.optString("uid")
        val col = vbox()
        col.setBackgroundColor(C.BG)
        col.addView(topBar(f.optString("username") + "  @" + f.optString("handle"), true), LinearLayout.LayoutParams(MATCH, WRAP))
        val box = vbox(12)
        val sv = ScrollView(this)
        sv.addView(box, FrameLayout.LayoutParams(MATCH, WRAP))
        chatBox = box
        chatScroll = sv
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = hbox()
        bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        bar.setBackgroundColor(C.CARD)
        val et = input("พิมพ์ข้อความ...", false, 500)
        bar.addView(et, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        bar.addView(smallBtn("ส่ง") {
            val text = et.text.toString().trim()
            if (text.isNotEmpty()) {
                et.setText("")
                call("msg_send", JSONObject().put("to", chatWith).put("text", text)) { r ->
                    if (r.optBoolean("ok")) addBubble(text, true) else toast(r.optString("err"))
                }
            }
        })
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        call("msg_hist", JSONObject().put("with", chatWith)) { r ->
            for (m in r.optJSONArray("msgs").objs()) {
                addBubble(m.optString("text"), m.optString("from") == Core.uid)
            }
        }
        return col
    }

    private fun addBubble(text: String, mine: Boolean) {
        val box = chatBox ?: return
        val t = tv(text, 15f, C.WHITE)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = roundBg(if (mine) 0xFF0369A1.toInt() else 0xFF831843.toInt(), 16)
        t.maxWidth = dp(260)
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.gravity = if (mine) Gravity.END else Gravity.START
        p.topMargin = dp(6)
        box.addView(t, p)
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    // ================================================================ profile
    private fun profileView(): View {
        val me = Core.me ?: JSONObject()
        val c = vbox(20)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val iv = avatarView(me.optString("avatar"), 110)
        iv.setOnClickListener {
            pickPhoto { b64 ->
                call("set_avatar", JSONObject().put("avatar", b64)) { r ->
                    if (r.optBoolean("ok")) {
                        Core.me = r.optJSONObject("me")
                        reload()
                    } else {
                        toast(r.optString("err"))
                    }
                }
            }
        }
        c.addView(iv)
        c.addView(tv("แตะรูปเพื่อเปลี่ยน", 11f, C.MUTED))
        c.addView(gap(12))

        val unWait = me.optInt("un_wait")
        val hWait = me.optInt("h_wait")
        c.addView(infoRow("ชื่อผู้ใช้", me.optString("username"),
            if (unWait > 0) "รออีก " + (unWait / 86400 + 1) + " วัน" else "เปลี่ยน") {
            if (unWait > 0) {
                toast("เปลี่ยนชื่อผู้ใช้ได้ 1 ครั้งต่อ 7 วัน")
            } else {
                askText("ชื่อผู้ใช้ใหม่", "ชื่อผู้ใช้", me.optString("username"), 20, charFilter(true, false)) { v ->
                    call("set_username", JSONObject().put("username", v)) { r ->
                        if (r.optBoolean("ok")) {
                            Core.me = r.optJSONObject("me")
                            reload()
                        } else {
                            toast(r.optString("err"))
                        }
                    }
                }
            }
        })
        c.addView(infoRow("@", me.optString("handle"),
            if (hWait > 0) "รออีก " + (hWait / 86400 + 1) + " วัน" else "เปลี่ยน") {
            if (hWait > 0) {
                toast("เปลี่ยน @ ได้ 1 ครั้งต่อ 30 วัน")
            } else {
                askText("@ ใหม่", "ชื่อ @", me.optString("handle"), 20, charFilter(false, true)) { v ->
                    call("set_handle", JSONObject().put("handle", v)) { r ->
                        if (r.optBoolean("ok")) {
                            Core.me = r.optJSONObject("me")
                            reload()
                        } else {
                            toast(r.optString("err"))
                        }
                    }
                }
            }
        })
        c.addView(infoRow("อีเมล", me.optString("email"), "") { })
        c.addView(gap(14))
        c.addView(tv("การตั้งค่า", 14f, C.BLUE, true))
        c.addView(infoRow("เซิร์ฟเวอร์", Core.server, "แก้ไข") {
            serverDialog {
                toast("เปลี่ยนเซิร์ฟเวอร์แล้ว กรุณาเข้าสู่ระบบใหม่")
                Core.logout()
                stack.clear()
                go("welcome") { welcomeView() }
            }
        })
        c.addView(infoRow("พอร์ตเกมในเครื่อง", Core.gamePort.toString(), "แก้ไข") {
            askText("พอร์ตเกม Minecraft", "ปกติ 19132", Core.gamePort.toString(), 5, null) { v ->
                val n = v.toIntOrNull()
                if (n != null && n in 1024..65535) {
                    Core.gamePort = n
                    reload()
                } else {
                    toast("พอร์ตต้องเป็นเลข 1024-65535")
                }
            }
        })
        val ov = if (Settings.canDrawOverlays(this)) "เปิดแล้ว" else "ยังไม่เปิด"
        c.addView(infoRow("แสดงทับแอปอื่น", ov, if (Settings.canDrawOverlays(this)) "" else "เปิด") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        })
        c.addView(gap(14))
        c.addView(btn("ออกจากระบบ", 1) {
            AlertDialog.Builder(this).setMessage("ออกจากระบบ?")
                .setPositiveButton("ออก") { _, _ ->
                    Core.logout()
                    stack.clear()
                    go("welcome") { welcomeView() }
                }.setNegativeButton("ยกเลิก", null).show()
        })
        return page("โปรไฟล์", scroll(c))
    }

    private fun infoRow(label: String, value: String, action: String, onClick: () -> Unit): View {
        val row = hbox()
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.background = roundBg(C.CARD, 14)
        val t = vbox()
        t.addView(tv(label, 11f, C.MUTED))
        t.addView(tv(if (value.isEmpty()) "-" else value, 15f, C.WHITE, true))
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (action.isNotEmpty()) row.addView(smallBtn(action, 1) { onClick() })
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(8)
        row.layoutParams = p
        return row
    }
}
