package com.blocklink.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private var api: Api? = null
    private var serverHost = ""
    private var me = ""
    private var bridge: HostBridge? = null
    private var proxy: JoinerProxy? = null
    private var hosting = false
    private val main = Handler(Looper.getMainLooper())
    private var snapTask: Runnable? = null
    private lateinit var root: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        showLogin()
    }

    override fun onDestroy() {
        super.onDestroy()
        proxy?.stop(); bridge?.stop(); api?.close()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun edit(h: String, pw: Boolean = false) = EditText(this).apply {
        hint = h
        setSingleLine(true)
        if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun bg(f: () -> Unit) {
        Thread {
            try { f() } catch (e: Exception) { toast(e.message ?: "error") }
        }.start()
    }

    private fun screen(vararg v: View) {
        root.removeAllViews()
        v.forEach { root.addView(it) }
    }

    private fun showLogin() {
        val prefs = getSharedPreferences("bl", MODE_PRIVATE)
        val s = edit("ที่อยู่เซิร์ฟเวอร์ (IP หรือโดเมน)").apply { setText(prefs.getString("srv", "")) }
        val n = edit("ชื่อบัญชี")
        val p = edit("รหัสผ่าน", true)
        fun go(op: String) {
            val host = s.text.toString().trim()
            val name = n.text.toString().trim()
            val pw = p.text.toString()
            if (host.isEmpty() || name.isEmpty() || pw.isEmpty()) { toast("กรอกให้ครบ"); return }
            prefs.edit().putString("srv", host).apply()
            bg {
                val a = Api(host)
                a.connect()
                val r = a.call(JSONObject().put("op", op).put("name", name).put("pw", pw))
                if (r.optBoolean("ok")) {
                    api = a; serverHost = host; me = name
                    runOnUiThread { showHome() }
                } else toast(r.optString("err", "ผิดพลาด"))
            }
        }
        screen(
            tv("BlockLink", 28f, true), tv("ต้นแบบทดสอบ", 14f), s, n, p,
            btn("เข้าสู่ระบบ") { go("login") }, btn("สมัครบัญชี") { go("register") }
        )
    }

    private fun showHome() {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = tv(if (hosting) "กำลังเปิดโลกอยู่" else "ยังไม่ได้เปิดโลก")
        val fn = edit("ชื่อบัญชีเพื่อน")
        val hostBtn = if (!hosting) btn("เปิดโลกให้คนอื่นเข้า") { hostDialog() } else btn("หยุดเปิดโลก") { stopHosting() }
        screen(
            tv("สวัสดี $me", 22f, true), status, hostBtn,
            tv("เพื่อนและโลกที่เปิดอยู่", 18f, true), list, btn("รีเฟรช") { loadList(list) },
            fn, btn("เพิ่มเพื่อน") { addFriend(fn.text.toString().trim(), list) },
            btn("ออกจากระบบ") { logout() }
        )
        loadList(list)
    }

    private fun loadList(list: LinearLayout) = bg {
        val r = api!!.call(JSONObject().put("op", "list"))
        runOnUiThread {
            list.removeAllViews()
            val fr = r.optJSONArray("friends") ?: JSONArray()
            for (i in 0 until fr.length()) {
                val f = fr.getJSONObject(i)
                list.addView(row(f.getString("name"), f.optJSONObject("room")))
            }
            val pub = r.optJSONArray("public") ?: JSONArray()
            if (pub.length() > 0) list.addView(tv("โลกที่เปิดให้ทุกคน", 16f, true))
            for (i in 0 until pub.length()) {
                val room = pub.getJSONObject(i)
                list.addView(row(room.getString("host"), room))
            }
            if (fr.length() == 0 && pub.length() == 0) list.addView(tv("ยังไม่มีเพื่อนหรือโลกที่เปิดอยู่"))
        }
    }

    private fun row(name: String, room: JSONObject?): View {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        l.addView(tv(name, 16f, true))
        if (room == null) {
            l.addView(tv("ออฟไลน์", 14f))
        } else {
            l.addView(tv("โลก: ${room.optString("world")} · เวอร์ชัน ${room.optString("version")}", 14f))
            l.addView(btn("เข้าร่วม") { joinRoom(room.getString("host")) })
        }
        return l
    }

    private fun addFriend(name: String, list: LinearLayout) {
        if (name.isEmpty()) return
        bg {
            val r = api!!.call(JSONObject().put("op", "add_friend").put("name", name))
            if (r.optBoolean("ok")) loadList(list) else toast(r.optString("err"))
        }
    }

    private fun hostDialog() {
        val w = edit("ชื่อโลก")
        val v = edit("เวอร์ชันเกม เช่น 1.21.0")
        val gp = edit("พอร์ตเกมในเครื่อง").apply { setText("19132") }
        val voice = Switch(this).apply { text = "แชตเสียง (ยังไม่เปิดใช้ในเวอร์ชันนี้)" }
        val pub = RadioButton(this).apply { text = "ทุกคนเข้าได้"; id = View.generateViewId() }
        val fr = RadioButton(this).apply { text = "เฉพาะเพื่อน"; id = View.generateViewId() }
        val g = RadioGroup(this).apply { addView(pub); addView(fr) }
        pub.isChecked = true
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            listOf(w, v, gp, voice, g).forEach { addView(it) }
        }
        AlertDialog.Builder(this).setTitle("เปิดโลก").setView(box)
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("เริ่ม") { _, _ ->
                startHosting(
                    w.text.toString().ifBlank { "World" }, v.text.toString(),
                    gp.text.toString().toIntOrNull() ?: 19132, voice.isChecked, pub.isChecked
                )
            }.show()
    }

    private fun startHosting(world: String, ver: String, port: Int, voice: Boolean, pub: Boolean) = bg {
        val r = api!!.call(
            JSONObject().put("op", "host_start").put("world", world).put("version", ver)
                .put("voice", voice).put("public", pub)
        )
        if (!r.optBoolean("ok")) { toast(r.optString("err")); return@bg }
        val br = HostBridge(serverHost, port)
        br.start()
        bridge = br
        api!!.onEvent = { ev -> if (ev.optString("ev") == "join") br.addSession(ev.getLong("sid").toInt()) }
        hosting = true
        runOnUiThread { showHome() }
    }

    private fun stopHosting() = bg {
        api!!.call(JSONObject().put("op", "host_stop"))
        bridge?.stop(); bridge = null
        hosting = false
        runOnUiThread { showHome() }
    }

    private fun joinRoom(host: String) = bg {
        val r = api!!.call(JSONObject().put("op", "join").put("host", host))
        if (!r.optBoolean("ok")) { toast(r.optString("err")); return@bg }
        val room = r.getJSONObject("room")
        val px = JoinerProxy(serverHost, r.getLong("sid").toInt(), 19133)
        px.start()
        proxy = px
        runOnUiThread { showJoin(room) }
    }

    private fun showJoin(room: JSONObject) {
        val host = room.optString("host")
        val img = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        val note = tv("รอภาพหน้าจอจากเจ้าของโลก (ยังไม่เปิดใช้ในเวอร์ชันนี้)", 13f)
        screen(
            tv(room.optString("world"), 22f, true),
            tv("เจ้าของ: $host"), tv("เวอร์ชัน: ${room.optString("version")}"),
            tv("ใน Minecraft ไปที่ Play > Servers > Add Server แล้วใส่ที่อยู่ 127.0.0.1 พอร์ต 19133", 14f),
            img, note, btn("ออก") { leaveRoom() }
        )
        val t = object : Runnable {
            override fun run() {
                bg {
                    val r = api!!.call(JSONObject().put("op", "snap_get").put("host", host))
                    val j = r.optString("jpg")
                    if (j.isNotEmpty()) {
                        val bytes = Base64.decode(j, Base64.DEFAULT)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) runOnUiThread { img.setImageBitmap(bmp); note.text = "" }
                    }
                }
                main.postDelayed(this, 3000)
            }
        }
        snapTask = t
        main.post(t)
    }

    private fun leaveRoom() {
        snapTask?.let { main.removeCallbacks(it) }
        proxy?.stop(); proxy = null
        showHome()
    }

    private fun logout() {
        snapTask?.let { main.removeCallbacks(it) }
        proxy?.stop(); bridge?.stop(); api?.close()
        proxy = null; bridge = null; api = null; hosting = false
        showLogin()
    }
}
